<?php
//echo "footer";
?>
<html>
    <footer>
        <ul>
            <li><a>Contact</a></li>
            <li><a>Mention légales</a></li>
            <!-- <li>
                <form method ='post' action = 'index.php'>
                    <input type = 'submit' name = 'disconnection' value = 'déconnexion'></input>
                <form>
            </li> -->
        </ul>
        
    </footer>
</html>