package controller;

import view.PanelAccount;
import view.PanelAppointments;
import view.PanelDoctors;
import view.PanelPatients;

public class GeneralController {
	public void afficher (int choix) {
		
	}

}
