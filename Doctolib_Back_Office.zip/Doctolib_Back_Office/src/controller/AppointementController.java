package controller;

public class AppointementController {
	private int idAppointment;
	private String dateAppointment, timeAppointment, reason, idPatient, idDoctor;
}
