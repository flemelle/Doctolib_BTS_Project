package controller;

public class PrescriptionController {
	private int idPrescription, idPatient, idDoctor;
	private String datePrescription, content;
}
