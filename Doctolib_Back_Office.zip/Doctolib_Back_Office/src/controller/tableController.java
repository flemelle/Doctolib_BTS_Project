package controller;

public class tableController {

	private String header []; 
	private Object data[][]; 
	
	public tableController(String[] header, Object[][] data) {
		super();
		this.setHeader(header);
		this.setData(data);
	}

	public String[] getHeader() {
		return header;
	}

	public void setHeader(String header[]) {
		this.header = header;
	}

	public Object[][] getData() {
		return data;
	}

	public void setData(Object data[][]) {
		this.data = data;
	}
}
