<?php

namespace Application\Lib\Database;

//echo 'database.php is running ';
class DatabaseConnection {
    public ?\PDO $database = null;
    public function getConnection(): \PDO
    {
        //echo 'DatabaseConnection\getConnection is running, ';
        if ($this -> database === null)
        {
            $this -> database = new \PDO('mysql:host=.mysql.db;dbname=;charset=utf8', '', '');
        }
        return $this -> database;
    }
}
?>
