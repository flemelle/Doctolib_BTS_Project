package view;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JPanel;

public class PanelModel extends JPanel{
	public PanelModel() {	
		//this.setBackground(new Color(255, 255, 255));
		this.setBounds(40, 40, 900, 400);
		this.setLayout(null);
		this.setVisible(false);
	}
}
